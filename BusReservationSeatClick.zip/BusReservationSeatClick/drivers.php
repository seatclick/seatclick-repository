<?php
    session_start();

    require ("function.php");

    $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
    $db = mysqli_select_db($conn, 'seatclickdatabase') or  die("database error");
    $query = "SELECT * FROM driver_information WHERE status = 'working' ORDER BY firstName ASC";
    $result = mysqli_query($conn,$query);

    if(isset($_POST['removeB']))
    {
        $mobileNum = $_POST['mobileRemove'];

        mysqli_query($conn,"UPDATE `driver_information` SET `status` = 'removed' WHERE `driver_information`.`mobileNum` = '$mobileNum'");

        echo '<script>alert("The Driver is REMOVED");
            window.location.href = "drivers.php";</script>';
    }

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Drivers-SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "adminIndex.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "adminIndex.php">SCHEDULE</a></li>
                        <li><a id = "navID" href = "drivers.php"  style = "color: white;">DRIVERS/CONDUCTORS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">REPORTS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">USERS</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <div class = "container-fluid">
            <div class = "row" id = "buttonsDriversCon">
                <div class = "col-md-4"></div>
                <div class = "col-md-2">
                    <form action = "drivers.php" id = "driversButton"><input type = "submit" name = "driversB" id = "driverB" value = "DRIVERS" style = "background: #3385ff; color: white;" disabled></form>
                </div>
                <div class = "col-md-2">
                    <form action = "conductor.php"id = "conductorButton"><input type = "submit" name = "conductorB" id = "conductorB" value = "CONDUCTORS"></form>
                </div>
                <div class = "col-md-4"></div>
            </div>
        </div>

        <div class = "container-fluid">
            <div class = "row" style = "margin-top: 5%;">
                <div class = "col-md-2"></div>
                <div class ="col-md-8">
                    <!-- Trigger the modal with a button -->
                    <button type="button" id = "addDriverB" data-toggle="modal" data-target="#myModal">Add Driver</button>

                    <!-- Modal -->
                    <div class="modal fade" id="myModal" role="dialog">
                        <div class="modal-dialog">
                        
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                            <h4 class="modal-title" id = "addDriverL">Add Driver</h4>
                            </div>
                            <div class="modal-body">
                            <form action = "addDrivers.php" method = "post">
                                <div id = "driverFormL">First Name </div><input type = "text" id = "driverInput" name = "driverFN" onkeyup = "lettersOnly(this)" maxlength = "35" required><br>
                                <div id = "driverFormL">Middle Name </div><input type = "text" id = "driverInput" name = "driverMN" onkeyup = "lettersOnly(this)" maxlength = "35"><br>
                                <div id = "driverFormL">Last Name </div><input type = "text" id = "driverInput" name = "driverLN" onkeyup = "lettersOnly(this)" maxlength = "35" required><br>
                                <div id = "driverFormL">Address </div><input type = "text" id = "driverInput" name = "driverAddress" maxlength = "200" required><br>
                                <div id = "driverFormL">Gender </div><input type="radio" id = "genderM" name="radio" value="male" required> Male
                                <input type="radio" id = "genderF" name="radio" value="female" required> Female<br>
                                <div id = "driverFormL">Birth Date </div><input type="date" id = "driverInput" name = "birthday" required value = "1960-01-01" min = "1960-01-01" max = "1995-12-31">
                                <div id = "driverFormL">Mobile Number</div><input type="text" id="driverInput" name="cpNum"onkeyup = "numbersOnly(this)" maxlength = "11" required>
                            </div>
                            <div class="modal-footer">
                            <input type = "submit" class="btn btn-default" name = "driverAddDB" id = "driverAddDB" value = "Add Driver">
                            </form>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                        
                        </div>
                    </div> 
                    <div class = "table-responsive" style = "box-shadow: 5px 10px #888888; border-radius: 4px;">
                        <table class="table table-striped">
                            <thead id = "tableHead">
                                            
                                <tr  id = "columnName" class = "info">
                                    <th id = "thName">First Name</th>
                                    <th id = "thName">Middle Name</th>
                                    <th id = "thName">Last Name</th>
                                    <th id = "thName">Address</th>
                                    <th id = "thName">Gender</th> 
                                    <th id = "thName">Birth Date</th>
                                    <th id = "thName">Mobile Number</th>
                                    <th id = "thName">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    while($rows = mysqli_fetch_assoc($result))
                                    {
                                ?>
                                    <tr id = "rowsName">
                                        <form action = "drivers.php" method = "post">
                                        <td id = "tdName"><?php echo $rows['firstName']?></td>
                                        <td id = "tdName"><?php echo $rows['middleName']?></td>
                                        <td id = "tdName"><?php echo $rows['lastName']?></td>
                                        <td id = "tdName"><?php echo $rows['address']?></td>
                                        <td id = "tdName"><?php echo $rows['gender']?></td>
                                        <td id = "tdName"><?php echo date('F d, Y',strtotime($rows['birthDate']))?></td>
                                        <td id = "tdName"><input type = "text" name = "mobileRemove" value = "<?php echo $rows['mobileNum']?>" style = "background: transparent; border: 0; text-align: center;" readOnly></td>
                                        <td id = "tdName"><input type = "submit" name = "removeB" id = "editTripB" value = "Remove"></td>
                                        </form>
                                    </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>

                </div>
                <div class = "col-md-2"></div>
            </div>
        </div>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>