<?php

    session_start();
    if(isset($_POST['driverAddDB']))
    {
        
        $fname = $_POST['driverFN'];
        $mname = $_POST['driverMN'];
        $lname = $_POST['driverLN'];
        $address = $_POST['driverAddress'];
        $gender = $_POST['radio'];
        $birthday = $_POST['birthday'];
        $mobnum = $_POST['cpNum'];


        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdatabase') or  die("database error");

        $query = mysqli_query($conn, "SELECT * FROM driver_information WHERE firstName = '$fname' AND lastName = '$lname' AND address = '$address' AND mobileNum = '$mobnum'");

        if(mysqli_num_rows($query) > 0)
        {
            echo '<script>alert("The driver already exist.");
            window.location.href = "drivers.php";</script>';
        }
        else
        {
            $fname = mysqli_real_escape_string($conn,$_POST['driverFN']);
            $lname = mysqli_real_escape_string($conn,$_POST['driverLN']);

            $sql = "CREATE TABLE `".$lname.','.$fname."_rating` (rating Int(10), comments VARCHAR(200))";
            if(mysqli_query($conn, $sql))
            {
                
                mysqli_query($conn,"INSERT INTO `driver_information` (`driverId`,`firstName`, `middleName`, `lastName`, `address`,`gender`,`birthDate`,`mobileNum`,`status`) VALUES
                ('','$fname', '$mname','$lname', '$address', '$gender','$birthday','$mobnum', 'working')") or die (mysqli_error());

                echo '<script>alert("Driver Added!"); 
                window.location.href = "drivers.php";</script>';
            }
        }
        mysqli_close($conn);       
    }      
?>