<?php

    session_start();
    if(isset($_POST['conductorAddDB']))
    {
        
        $fname = $_POST['driverFN'];
        $mname = $_POST['driverMN'];
        $lname = $_POST['driverLN'];
        $address = $_POST['driverAddress'];
        $gender = $_POST['radio'];
        $birthday = $_POST['birthday'];
        $mobnum = $_POST['cpNum'];


        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdatabase') or  die("database error");

        $query = mysqli_query($conn, "SELECT * FROM conductor_information WHERE firstName = '$fname' AND lastName = '$lname' AND address = '$address' AND mobileNum = '$mobnum'");

        if(mysqli_num_rows($query) > 0)
        {
            echo '<script>alert("The Conductor already exist.");
            window.location.href = "conductor.php";</script>';
        }
        else
        {
                
                mysqli_query($conn,"INSERT INTO `conductor_information` (`conductorId`,`firstName`, `middleName`, `lastName`, `address`,`gender`,`birthDate`,`mobileNum`,`status`) VALUES
                ('','$fname', '$mname','$lname', '$address', '$gender','$birthday','$mobnum', 'working')") or die (mysqli_error());

                echo '<script>alert("Conductor Added!"); 
                window.location.href = "conductor.php";</script>';
        }
        mysqli_close($conn);       
    }      
?>