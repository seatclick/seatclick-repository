<?php
    session_start();

    require ("function.php");

    $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
    $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");

    $username = mysqli_real_escape_string($conn,$_SESSION['username']);

    $query = "SELECT * FROM passenger_info WHERE userName = '$username'";
    $result = mysqli_query($conn,$query);

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "welcome.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "profile.php" style = "text-transform: Uppercase;">
                        <?php
                        if(isset($_SESSION['username']))
                        {
                            $userData = getUserData(getID($_SESSION['username']));
                        ?>
                        <?php 
                            echo $userData['firstName']." ".$userData['lastName'];

                        ?>
                        <?php
                            }
                        ?>
                        <li><a id = "navID" href = "trips.php">SHOW TRIP HISTORY</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <!-- Profile-->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-4"></div>
                <div class = "col-md-4">
                    <div id = "userProfile">
                        <div id = "profileL">Passenger Information</div>
                        
                        <?php
                            while($rows = mysqli_fetch_assoc($result))
                            {
                        ?>
                        <form id = "userProfileForm">
                            First Name: <input type = "text" id = "firstnameProfile" value = "<?php echo $rows['firstName']?>" disabled><br>
                            Middle Name: <input type = "text" id = "middlenameProfile" value = "<?php echo $rows['middleName']?>" disabled><br>
                            Last Name: <input type = "text" id = "lastnameProfile" value = "<?php echo $rows['lastName']?>" disabled><br>
                            Gender: <input type = "text" id = "genderProfile"value = "<?php echo $rows['gender']?>" disabled><br>
                            Birthday: <input type = "text" id = "birthdayProfile"value = "<?php echo date('F d, Y',strtotime($rows['birthDate']))?>" disabled><br>
                            Email: <input type = "text" id = "emailProfile"value = "<?php echo $rows['emailAdd']?>" disabled><br>
                            Mobile No.: <input type = "text" id = "mobileProfile"value = "<?php echo $rows['mobileNum']?>" disabled><br>
                        </form>
                    </div> 
                        <div id = "userProfileAccounts">
                            <div id = "profileAccount">Passenger Account</div>
                            <form id = "userAccountProfile">
                                Username <input type = "text" id = "usernameProfile" value = "<?php echo $rows['userName']?>" disabled><br>
                                Password <input type = "password" id = "passwordProfile" value = "<?php echo $rows['password']?>" disabled>
                                <input type="checkbox" onclick="showPassword()">Show Password
                            </form>
                        </div>

                       <?php
                            }
                        ?>
                </div>
                <div class = "col-md-4"></div>
            </div>
        </div>
            <!-- SHOW PASSWORD -->
            <script>
                function showPassword() {
                    var x = document.getElementById("passwordProfile");
                    if (x.type === "password") {
                        x.type = "text";
                    } else {
                        x.type = "password";
                    }
                }
            </script>
        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>