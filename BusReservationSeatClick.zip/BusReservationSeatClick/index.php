<?php
    require ("function.php");
    $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
    $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
?>
<!DOCTYPE html>
<html>

    <head>

        <title>SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
					<a href = "index.php"><img src = "assets/logo.png"/></a>
                </div>

                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "faqs.html">FAQs</a></li>
                        <li><a id = "navID" href = "signIn.php">SIGN IN</a></li>
                        <li><a id = "navID" href = "signUp.php">SIGN UP</a></li>
                        <li><a id = "navID" href = "contactUs.php">CONTACT US</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-2"></div>

                <div class = "col-md-8">
                    <div id = "welcomeMessage">
                        <h1 id ="tagline">Safe and Relaxing Journey Starts Here.</h1>
                        <input type = "submit" id = "howToBookB" value = "HOW TO BOOK"/> 
                    </div>

                    <div id = "showTripForm">
                        <form action = "showTripIndex.php" method = "post">
                            <select name = "originF" id = "originF">
                            
                            <?php

                                $query = "SELECT * FROM origin";
                                $result = mysqli_query($conn,$query);
                                while($rows = mysqli_fetch_assoc($result))
                                {
                            ?>
                                <option id = "originO" value = "<?php echo $rows['depPlace']?>"><?php echo $rows['depPlace']?></option>
                            <?php
                                }
                            ?>
                            </select>

                            <select name = "destinationF" id = "destinationF">

                            <?php

                                $query = "SELECT arivalPlace FROM destination";
                                $result = mysqli_query($conn,$query);
                                while($rows = mysqli_fetch_assoc($result))
                                {
                            ?>
                                <option id = "destinationO" value="<?php echo $rows['arivalPlace']?>"><?php echo $rows['arivalPlace']?></option>
 
                            <?php
                                }
                            ?>
                            </select>

                            <input type="date" id = "depDate" name = "departDate" min = "<?php echo date('Y-m-d'); ?>"/>
                            <input type="submit" id = "showTripB" name = "showTripB"value = "Show Trips">
                        </form>
                    </div>
                </div>

                <div class = "col-md-2"></div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>