<?php
    session_start();

    require ("function.php");

    if(isset($_POST['showTripB']))
    {
        $origin = $_POST['originF'];
        $destination = $_POST['destinationF'];
        $departureDate = $_POST['departDate'];

        if($departureDate == null)
        {
        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
        $query = "SELECT * FROM bus_trips WHERE destination = '$destination' ORDER BY departureDate ASC";
        $result = mysqli_query($conn,$query);
        }
        else
        {
        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
        $query = "SELECT * FROM bus_trips WHERE destination = '$destination' AND departureDate = '$departureDate'";
        $result = mysqli_query($conn,$query);
        }
        
    }
    else
    {
        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
        $query = "SELECT * FROM bus_trips";
        $result = mysqli_query($conn,$query);
    }


    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "welcome.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "profile.php" style = "text-transform: Uppercase;">
                        <?php
                        if(isset($_SESSION['username']))
                        {
                            $userData = getUserData(getID($_SESSION['username']));
                        ?>
                        <?php 
                            echo $userData['firstName']." ".$userData['lastName'];

                        ?>
                        <?php
                            }
                        ?>
                        <li><a id = "navID" href = "trips.php">SHOW TRIP HISTORY</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <!-- Pick Origin,Destination and Date-->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-2"></div>

                <div class = "col-md-8">

                    <div id = "showTripFormUser">
                        <form action = "welcome.php" method = "post">
                            <select name = "originF" id = "originF" required>
                                <option id = "originO" value = "Cubao" selected>Cubao</option>
                            </select>

                            <select name = "destinationF" id = "destinationF" required>
                                <option id = "destinationO" value="Batangas">Batangas</option>
                                <option id = "destinationO" value="Baguio">Baguio</option>
                                <option id = "destinationO" value="Cavite">Cavite</option>
                                <option id = "destinationO" value="Laguna">Laguna</option>
                                <option id = "destinationO" value="Quezon">Quezon</option>
                                <option id = "destinationO" value="Subic">Subic</option>
                                <option id = "destinationO" value="Pampanga">Pampanga</option>
                            </select>

                            <input type="date" id = "depDate" name = "departDate" min = "<?php echo date('Y-m-d'); ?>"  />
                            <input type="submit" id = "showTripB" name = "showTripB" value = "Show Trips">
                        </form>
                    </div>
                </div>

                <div class = "col-md-2"></div>
            </div>
        </div>

        <!-- Steps -->
        <div class = "container-fluid">
            <div class = "row">
                <div id = "stepsForm" class = "col-md-2" style = "margin-left: 2%; margin-top: 3%; margin-bottom: 5%;">
                    Step 1: <input id = "reserveSteps" type = "submit" value = "Plan Your Trip" style = "background: #3385ff;" disabled><br>
                    Step 2: <input id = "reserveSteps" type = "submit" value = "Choose Seats"><br>
                    Step 3: <input id = "reserveSteps" type = "submit" value = "Payment">
                </div>
                <div id = "tableForm" class = "col-md-9" style = "margin-left: 2%;margin-top: 2%;margin-bottom: 5%;">
                    <div class = "table-responsive">
                        <table class="table table-striped">
                            <thead id = "tableHead">
                                    <div id = "theadL" style = "text-transform: uppercase; margin-bottom: 2%; margin-top: 2%;">TRIPS</div>
                                
                                <tr  id = "columnName" class = "info">
                                    <th id = "thName">Operator</th>
                                    <th id = "thName">Bus Number</th>
                                    <th id = "thName">Driver Name</th>
                                    <th id = "thName">Departure Date</th>
                                    <th id = "thName">Origin</th> 
                                    <th id = "thName">Departure</th>
                                    <th id = "thName">Destination</th>
                                    <th id = "thName">Estimated Arrival</th>
                                    <th id = "thName">Bus Type</th>
                                    <th id = "thName">Fare</th>
                                    <th id = "thName">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    while($rows = mysqli_fetch_assoc($result))
                                    {
                                ?>
                                <form action = "reservePassenger.php" method = "post">
                                    <tr id = "rowsName">
                                        <td id = "tdName"><?php echo $rows['operator']?></td>
                                        <td id = "tdName"><input type = "text" name = "busNumberReserve" style = "border: 0; background: transparent; text-align: center; width: 50px;" value = "<?php echo $rows['busNo']?>" readOnly></td>
                                        <td id = "tdName"><input type = "text" name = "busDriverReserve" style = "text-transform: capitalize;border: 0; background: transparent; text-align: center; width: 120px;" value ="<?php echo $rows['driverName']?>" readOnly></td>
                                        <td id = "tdName"><input type = "text" name = "busDepartDateReserve" style = "text-transform: capitalize;border: 0; background: transparent; text-align: center; width: 120px;" value ="<?php echo $rows['departureDate']?>"readOnly></td>
                                        <td id = "tdName"><?php echo $rows['origin']?></td>
                                        <td id = "tdName"><?php echo $rows['departureTime']?></td>
                                        <td id = "tdName"><?php echo $rows['destination']?></td>
                                        <td id = "tdName"><?php echo $rows['arivalTime']?></td>
                                        <td id = "tdName"><?php echo $rows['busType']?></td>
                                        <td id = "tdName"><?php echo $rows['fare']?></td>
                                        <td id = "tdName">
                                            <?php 
                                                if($rows['action'] == "Available")
                                                {
                                            ?>
                                                    <input type = "submit" name = "reserveB" id = "reserveB" value = "Reserve">
                                            <?php
                                                }
                                                else
                                                {
                                                    echo "Not Available";
                                                } 
                                            ?>
                                        </td>
                                    </form>
                                    </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <div class = "col-md-1"></div>
                </div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>