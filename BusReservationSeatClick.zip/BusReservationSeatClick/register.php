<?php

    session_start();
    if(isset($_POST['register']))
    {
        
        $fname = $_POST['firstname'];
        $mname = $_POST['midname'];
        $lname = $_POST['lastname'];
        $email = $_POST['emailAdd'];
        $gender = $_POST['radio'];
        $birthday = $_POST['birthday'];
        $mobnum = $_POST['cpNum'];
        $username = $_POST['usename'];
        $confirmpass = $_POST['usepasscon'];


        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdatabase') or  die("database error");

        $query = mysqli_query($conn, "SELECT * FROM passenger_information WHERE emailAdd = '$email' AND mobileNum = '$mobnum' AND userName = '$username' AND password = '$confirmpass'");

        if(mysqli_num_rows($query) > 0)
        {
            echo '<script>alert("The account already exist.");
            window.location.href = "signUp.php";</script>';
        }
        else
        {
            $username = mysqli_real_escape_string($conn,$_POST['usename']);
            $sql = "CREATE TABLE `".$username."` (transNo INT AUTO_INCREMENT,username VARCHAR(100), operator VARCHAR(100), driverName VARCHAR(100), departureDate DATE, origin VARCHAR(25), departureTime VARCHAR(25), destination VARCHAR(25), arivalTime VARCHAR(25), fare VARCHAR(20), status VARCHAR(100),action VARCHAR(50), PRIMARY KEY (transNo))";
            if(mysqli_query($conn, $sql))
            {
                $_SESSION['username']= $username;
                
                mysqli_query($conn,"INSERT INTO `passenger_information` (`passengerId`,`firstName`, `middleName`, `lastName`, `emailAdd`,`gender`,`birthDate`,`mobileNum`,`userName`,`password`) VALUES
                ('','$fname', '$mname','$lname', '$email', '$gender','$birthday','$mobnum','$username','$confirmpass')") or die (mysqli_error());

                echo '<script>alert("You are now Registered!"); 
                window.location.href = "signIn.php";</script>';
            }
        }
        mysqli_close($conn);       
    }      
?>