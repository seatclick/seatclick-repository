<?php
    session_start();

    require ("function.php");

    $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
    $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
    $query = "SELECT * FROM bus_trips ORDER BY departureDate ASC";
    $result = mysqli_query($conn,$query);

    if(isset($_POST['busScheduleB']))
    {
        $destination = $_POST['destinationF'];
        $departureDate = $_POST['busDepartDate'];

        if($departureDate != null && $destination != "ALL")
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips WHERE departureDate = '$departureDate' AND destination = '$destination' ORDER BY departureDate ASC";
            $result = mysqli_query($conn,$query);
        }
        else if($departureDate == null && $destination == "ALL")
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips ORDER BY departureDate, destination ASC";
            $result = mysqli_query($conn,$query);
        }
        else if ($departureDate != null && $destination == "ALL")
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips WHERE departureDate = '$departureDate' ORDER BY departureDate,destination ASC";
            $result = mysqli_query($conn,$query);
        }
        else if ($departureDate == null && $destination != "ALL")
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips WHERE destination = '$destination' ORDER BY departureDate ASC";
            $result = mysqli_query($conn,$query);
        }
    }
    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Admin-SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "adminIndex.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "adminIndex.php" style = "color: white;">SCHEDULE</a></li>
                        <li><a id = "navID" href = "drivers.php">DRIVERS/CONDUCTORS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">REPORTS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">USERS</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        
        <!-- Schedule table -->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-1"></div>
                <div class = "col-md-10">
                    <div id = "scheduleContainer">
                        <div id = "dailySchedL">Daily Schedule</div><hr>
                        <form action = "adminIndex.php" method = "post" id = "busDepartureDate">
                            Bus on : <input type = "date" name = "busDepartDate" id = "busDepartDate" />
                                Filter by route: Cubao to  
                            <select name = "destinationF" id = "destinationAdmin">
                                <option id = "destinationOption" selected>ALL</option>                                    
                                <option id = "destinationOption" value="Batangas">Batangas</option>
                                <option id = "destinationOption" value="Baguio">Baguio</option>
                                <option id = "destinationOption" value="Cavite">Cavite</option>
                                <option id = "destinationOption" value="Laguna">Laguna</option>
                                <option id = "destinationOption" value="Quezon">Quezon</option>
                                <option id = "destinationOption" value="Subic">Subic</option>
                                <option id = "destinationOption" value="Pampanga">Pampanga</option>
                            </select>
                            <input type = "submit" name = "busScheduleB" id = "busScheduleB" value = "VIEW">
                        </form>
                        
                        <input type = "submit" name = "addBusTripAdmin" id = "addBusTripAdmin" value = "ADD TRIP" data-toggle="modal" data-target="#myModal"><br><br>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="modal-title" id="myModalLabel">Add Bus Trip</h4>
                            </div>
                            <div class="modal-body">
                                <form action = "addTripDB.php" method = "post" id = "addTripFormModal" style = "text-align: center;">
                                        <input type="text" style = "margin-bottom: 2%;  width: 30%; padding: 5px 0; border-radius: 8px; border: 1px solid black;" id="busNum" name="busNum" placeholder="Bus Number" maxlength = "35" required>
                                        <br>

                                    <select id = "operatorForm" name = "operator" style = "margin-bottom: 2%; text-align: center; width: 40%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                        <option disabled selected>Select Operator</option>
                                        <option id = "operatorO" value = "Power Transit">Power Transit</option>
                                    </select>

                                        <br>

                                        <input type="text" id="dname" name="drivername" placeholder="Driver's name" onkeyup = "lettersOnly(this)" maxlength = "35" style = "margin-bottom: 2%;width: 60%; padding: 5px 0; border-radius: 8px; border: 1px solid black;"required>
                                        <br>

                                        <input type="date" id = "departDate" name = "departDate" required min = "<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" style = "margin-bottom: 2%; width: 40%; padding: 5px 0; border-radius: 8px; border: 1px solid black;"/>
                                        <br>

                                    <select id = "originForm" name = "originAdmin" style = "margin-bottom: 2%; text-align: center; width: 30%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                        <option disabled selected>Select origin</option>
                                        <option value = "Cubao">Cubao</option>
                                    </select>

                                        <select id = "departureTimeForm" name = "departureAdmin" style = "margin-bottom: 2%; text-align: center; width: 30%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                        <option disabled selected>Departure time</option>
                                        <option value = "8:00 AM">8:00 AM</option>
                                        <option value = "9:00 AM">9:00 AM</option>
                                        <option value = "10:00 AM">10:00 AM</option>
                                        <option value = "11:00 AM">11:00 AM</option>
                                        <option value = "12:00 PM">12:00 PM</option>
                                        <option value = "1:00 PM">1:00 PM</option>
                                        <option value = "2:00 PM">2:00 PM</option>
                                        <option value = "3:00 PM">3:00 PM</option>
                                        <option value = "4:00 PM">4:00 PM</option>
                                        <option value = "5:00 PM">5:00 PM</option>
                                        <option value = "6:00 PM">6:00 PM</option>
                                        <option value = "7:00 PM">7:00 PM</option>
                                        <option value = "8:00 PM">8:00 PM</option>
                                        <option value = "9:00 PM">9:00 PM</option>
                                        <option value = "10:00 PM">10:00 PM</option>
                                        <option value = "11:00 PM">11:00 PM</option>
                                        <option value = "12:00 AM">12:00 AM</option>
                                    </select>
                                        <br>
                                        <select id = "destinationForm" name = "destinationAdmin" style = "margin-bottom: 2%; text-align: center; width: 30%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                            <option disabled selected>Select Destination</option>
                                            <option value="Cavite">Cavite</option>
                                            <option value="Batangas">Batangas</option>
                                            <option value="Laguna">Laguna</option>
                                            <option value="Quezon">Quezon</option>
                                            <option value="Baguio">Baguio</option>
                                            <option value="Subic">Subic</option>
                                            <option value="Pampanga">Pampanga</option>
                                        </select>
                                        <select id = "arivalTimeForm" name = "arivalAdmin" style = "margin-bottom: 2%; text-align: center; width: 30%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                        <option disabled selected>Arival time</option>
                                        <option value = "8:00 AM">8:00 AM</option>
                                        <option value = "9:00 AM">9:00 AM</option>
                                        <option value = "10:00 AM">10:00 AM</option>
                                        <option value = "11:00 AM">11:00 AM</option>
                                        <option value = "12:00 PM">12:00 PM</option>
                                        <option value = "1:00 PM">1:00 PM</option>
                                        <option value = "2:00 PM">2:00 PM</option>
                                        <option value = "3:00 PM">3:00 PM</option>
                                        <option value = "4:00 PM">4:00 PM</option>
                                        <option value = "5:00 PM">5:00 PM</option>
                                        <option value = "6:00 PM">6:00 PM</option>
                                        <option value = "7:00 PM">7:00 PM</option>
                                        <option value = "8:00 PM">8:00 PM</option>
                                        <option value = "9:00 PM">9:00 PM</option>
                                        <option value = "10:00 PM">10:00 PM</option>
                                        <option value = "11:00 PM">11:00 PM</option>
                                        <option value = "12:00 AM">12:00 AM</option>
                                    </select>
                                    <br>
                                    <select id = "bustTypeForm" name = "busTypeAdmin" style = "margin-bottom: 2%; text-align: center; width: 40%; padding: 5px 0; border-radius: 8px; border: 1px solid black;">
                                        <option disabled selected>Select Bus Type</option>
                                        <option value = "EXECUTIVE (2X1 WITH CR)">EXECUTIVE (2X1 WITH CR)</option>
                                    </select>
                                        <br>

                                        <input type="number" id="fareL" name="fare" placeholder = "Fare" onkeyup = "numbersOnly(this)" style = "margin-bottom: 2%; width: 20%; padding: 5px 0; border-radius: 8px; border: 1px solid black;" required>
                                        <br>
                                        <hr>
                                    <button type="submit" class="btn btn-primary" name = "addtrip" style = "width: 50%;">Add Trip</button>
                                    </form>
                            </div>
                            </div>
                        </div>
                        </div>

                            <div class = "table-responsive">
                                <table class="table table-striped">
                                    <thead id = "tableHead">
                                            
                                        <tr  id = "columnName" class = "info">
                                            <th id = "thName">Operator</th>
                                            <th id = "thName">Bus Number</th>
                                            <th id = "thName">Driver Name</th>
                                            <th id = "thName">Departure Date</th>
                                            <th id = "thName">Origin</th> 
                                            <th id = "thName">Departure</th>
                                            <th id = "thName">Destination</th>
                                            <th id = "thName">Estimated Arrival</th>
                                            <th id = "thName">Bus Type</th>
                                            <th id = "thName">Fare</th>
                                            <th id = "thName">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            while($rows = mysqli_fetch_assoc($result))
                                            {
                                        ?>
                                            <tr id = "rowsName">
                                                <td id = "tdName"><?php echo $rows['operator']?></td>
                                                <td id = "tdName"><?php echo $rows['busNo']?></td>
                                                <td id = "tdName" style = "text-transform: capitalize;"><?php echo $rows['driverName']?></td>
                                                <td id = "tdName"><?php echo date('F d, Y',strtotime($rows['departureDate']))?></td>
                                                <td id = "tdName"><?php echo $rows['origin']?></td>
                                                <td id = "tdName"><?php echo $rows['departureTime']?></td>
                                                <td id = "tdName"><?php echo $rows['destination']?></td>
                                                <td id = "tdName"><?php echo $rows['arivalTime']?></td>
                                                <td id = "tdName"><?php echo $rows['busType']?></td>
                                                <td id = "tdName"><?php echo $rows['fare']?></td>
                                                <td id = "tdName">
                                                    <?php 
                                                        if($rows['action'] == "Available")
                                                        {
                                                    ?>
                                                            
                                                                <input type = "submit" name = "editTripB" id = "editTripB" value = "Edit">
                                                                <input type = "submit" name = "deleteTripB" id = "deleteTripB" value = "Delete">
                                                    <?php
                                                        }
                                                        else
                                                        {
                                                            echo "Not Available";
                                                        } 
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php
                                            }
                                        ?>
                                    </tbody>
                                </table>
                        </div>
                    </div>
                </div>
                <div class = "col-md-1"></div>
            </div>
        </div>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>