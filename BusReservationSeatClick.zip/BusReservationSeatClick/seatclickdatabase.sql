-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2018 at 03:49 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seatclickdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `bus_information`
--

CREATE TABLE `bus_information` (
  `busNo` int(11) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `plateNo` varchar(255) NOT NULL,
  `busType` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `conductor_information`
--

CREATE TABLE `conductor_information` (
  `conductorId` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `birthDate` date NOT NULL,
  `mobileNum` varchar(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `conductor_information`
--

INSERT INTO `conductor_information` (`conductorId`, `firstName`, `middleName`, `lastName`, `address`, `gender`, `birthDate`, `mobileNum`, `status`) VALUES
(1, 'Patrick', 'Quinsa', 'Makabana', '#110 Bonifacio St. Pasong Tamo, Quezon City', 'male', '1991-05-04', '09471248763', 'working'),
(2, 'Edmundo', 'Villa', 'Cruz', '#98 San Roque St. Holy Spirit, Quezon City', 'male', '1995-11-18', '09784215432', 'working'),
(3, 'Josefino', 'Perez', 'Reyes', '#22 Pampanga St. Bonifaco Compound, Quezon City', 'male', '1975-07-05', '09874512545', 'working');

-- --------------------------------------------------------

--
-- Table structure for table `del monte,ronald_rating`
--

CREATE TABLE `del monte,ronald_rating` (
  `rating` int(10) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `arivalPlace` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`arivalPlace`) VALUES
('Batangas'),
('Baguio'),
('Cavite'),
('Laguna'),
('Quezon'),
('Subic'),
('Pampanga');

-- --------------------------------------------------------

--
-- Table structure for table `djsdeguzman`
--

CREATE TABLE `djsdeguzman` (
  `transNo` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `driverName` varchar(100) DEFAULT NULL,
  `departureDate` date DEFAULT NULL,
  `origin` varchar(25) DEFAULT NULL,
  `departureTime` varchar(25) DEFAULT NULL,
  `destination` varchar(25) DEFAULT NULL,
  `arivalTime` varchar(25) DEFAULT NULL,
  `fare` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `driver_information`
--

CREATE TABLE `driver_information` (
  `driverId` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `birthDate` date NOT NULL,
  `mobileNum` varchar(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `driver_information`
--

INSERT INTO `driver_information` (`driverId`, `firstName`, `middleName`, `lastName`, `address`, `gender`, `birthDate`, `mobileNum`, `status`) VALUES
(3, 'Jose', 'Cruz', 'Trinidad', '#53 Mayaman Street, Concepcion, Marikina City', 'male', '1969-11-09', '09785221458', 'working'),
(4, 'Ronald', 'Garcia', 'Del Monte', '#10 Ilang-Ilang Street, Holy Spirit, Quezon City', 'male', '1975-03-14', '09457878121', 'working'),
(5, 'Nelson', 'Ostras', 'Javier', '#48 Masigasig St. Pasong Tamo, Quezon City', 'male', '1965-06-23', '09745214576', 'working');

-- --------------------------------------------------------

--
-- Table structure for table `javier,nelson_rating`
--

CREATE TABLE `javier,nelson_rating` (
  `rating` int(10) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `origin`
--

CREATE TABLE `origin` (
  `depPlace` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `origin`
--

INSERT INTO `origin` (`depPlace`) VALUES
('Cubao');

-- --------------------------------------------------------

--
-- Table structure for table `passenger_information`
--

CREATE TABLE `passenger_information` (
  `passengerId` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAdd` varchar(255) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `birthDate` date NOT NULL,
  `mobileNum` varchar(11) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger_information`
--

INSERT INTO `passenger_information` (`passengerId`, `firstName`, `middleName`, `lastName`, `emailAdd`, `gender`, `birthDate`, `mobileNum`, `userName`, `password`) VALUES
(1, 'Admin', 'Admin', 'Admin', 'seatclick2018@gmail.com', 'male', '1998-11-26', '09154122549', 'Admin', 'admin2018'),
(2, 'diana jean', 'san diego', 'de guzman', 'djsdeguzman@gmail.com', 'female', '1999-05-23', '09981925425', 'djsdeguzman', 'dianajean');

-- --------------------------------------------------------

--
-- Table structure for table `trinidad,jose_rating`
--

CREATE TABLE `trinidad,jose_rating` (
  `rating` int(10) DEFAULT NULL,
  `comments` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bus_information`
--
ALTER TABLE `bus_information`
  ADD PRIMARY KEY (`busNo`);

--
-- Indexes for table `conductor_information`
--
ALTER TABLE `conductor_information`
  ADD PRIMARY KEY (`conductorId`);

--
-- Indexes for table `djsdeguzman`
--
ALTER TABLE `djsdeguzman`
  ADD PRIMARY KEY (`transNo`);

--
-- Indexes for table `driver_information`
--
ALTER TABLE `driver_information`
  ADD PRIMARY KEY (`driverId`);

--
-- Indexes for table `passenger_information`
--
ALTER TABLE `passenger_information`
  ADD PRIMARY KEY (`passengerId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bus_information`
--
ALTER TABLE `bus_information`
  MODIFY `busNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `conductor_information`
--
ALTER TABLE `conductor_information`
  MODIFY `conductorId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `djsdeguzman`
--
ALTER TABLE `djsdeguzman`
  MODIFY `transNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `driver_information`
--
ALTER TABLE `driver_information`
  MODIFY `driverId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `passenger_information`
--
ALTER TABLE `passenger_information`
  MODIFY `passengerId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
