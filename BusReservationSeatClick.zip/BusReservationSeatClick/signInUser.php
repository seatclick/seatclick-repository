<?php

        session_start();
        if(isset($_POST['signInB']))
        {
            $username = $_POST['signName'];
            $password = $_POST['signpass'];


            $conn = new mysqli('localhost', 'root', ''  ) or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdatabase') or  die("database error");

            $query = mysqli_query($conn, "SELECT * FROM passenger_information WHERE userName = '$username' AND password = '$password'");
            
            if(mysqli_num_rows($query) > 0)
            {
                $_SESSION['username']= $username;
                if( $_SESSION['username'] == "Admin" || $_SESSION['username'] == "admin")
                {
                    echo '<script>alert("You are now Sign In as '.$_SESSION['username'].' !!");
                    window.location.href = "adminIndex.php";</script>';
                }
                else
                {
                    echo '<script>window.location.href = "welcome.php";</script>';
                }
            }
            else
            {
                echo '<script>alert("You entered a WRONG username or password");
                window.location.href = "signIn.php";</script>';
            }       
        }
?>