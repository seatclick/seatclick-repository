<?php

    session_start();

    require ("function.php");

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    }

    if(isset($_POST['reserveB']))
    {
        $busNo = $_POST['busNumberReserve'];
        $busDriver = $_POST['busDriverReserve'];
        $busDepartDate = $_POST['busDepartDateReserve'];

        $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");


    }
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "welcome.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "profile.php" style = "text-transform: Uppercase;">
                        <?php
                        if(isset($_SESSION['username']))
                        {
                            $userData = getUserData(getID($_SESSION['username']));
                        ?>
                        <?php 
                            echo $userData['firstName']." ".$userData['lastName'];

                        ?>
                        <?php
                            }
                        ?>
                        <li><a id = "navID" href = "trips.php">SHOW TRIP HISTORY</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Steps -->
        <div class = "container-fluid">
            <div class = "row">
                <div id = "stepsForm" class = "col-md-2" style = "margin-left: 2%; margin-top: 3%; margin-bottom: 5%;">
                    Step 1: <form action = "welcome.php"><input id = "reserveSteps" type = "submit" value = "Plan Your Trip" style = "background: #3385ff;"><br></form>
                    Step 2: <input id = "reserveSteps" type = "submit" value = "Choose Seats" style = "background: #3385ff;" disabled><br>
                    Step 3: <input id = "reserveSteps" type = "submit" value = "Payment">
                </div>
                <div class = "col-md-7">
                    <div id = "busStructure" style = "margin: 5% 20%; border: 1px solid black;">

                        <div id = "busNumberReserve" style = "margin: 4%; text-align: center; border: 1px solid black; font-size: 30px; font-weight: bold;">
                        <?php echo $busNo?>
                        </div>
                    <?php
                        $query = "SELECT * FROM `".$busDriver.'_'.$busDepartDate."`";
                        $result = $result = mysqli_query($conn,$query);
                        while($rows = mysqli_fetch_assoc($result))
                        {
                            if($rows['seatNo'] == "A1")
                            {
                                if($rows['status'] == "Available")
                                {?>
                                <input type = "submit"  style = "font-size: 12px;border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']." "."(PWD/SS)";?>">
                            <?php
                                }
                                else
                                {
                                ?>
                                <input type = "submit" style = "background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>" disabled>
                                <?php
                                }
                            }
                            else if($rows['seatNo'] == "A2")
                            {
                                if($rows['status'] == "Available")
                                {
                                ?>
                                <input type = "submit"  style = "font-size:12px; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']." "."(PWD/SS)";?>">
                            <?php
                                }
                                else
                                {?>
                                <input type = "submit"  style = "background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>"disabled>
                                <?php
                                }
                            }
                            else if($rows['seatNo'] == "A3")
                            {
                                if($rows['status'] == "Available")
                                {
                                ?>
                                <input type = "submit"  style = "font-size: 12px; float: right;border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']." "."(PWD/SS)";?>"><br>
                            <?php
                                }
                                else
                                {?>
                                <input type = "submit"  style = "float: right; background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>"disabled><br>
                                <?php
                                }
                            }
                            else if($rows['seatNo'] == "B1" || $rows['seatNo'] == "C1" || $rows['seatNo'] == "D1" || $rows['seatNo'] == "E1"|| $rows['seatNo'] == "F1"|| $rows['seatNo'] == "G1"|| $rows['seatNo'] == "H1"|| $rows['seatNo'] == "I1" )
                            {
                                if($rows['status'] == "Available")
                                {
                                ?>
                                <input type = "submit"  style = "border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']?>">
                            <?php
                                }
                                else
                                {?>
                                <input type = "submit"  style = "background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>"disabled>
                                <?php
                                }
                            }
                            else if($rows['seatNo'] == "B2" || $rows['seatNo'] == "C2" || $rows['seatNo'] == "D2" || $rows['seatNo'] == "E2" || $rows['seatNo'] == "F2"|| $rows['seatNo'] == "G2"|| $rows['seatNo'] == "H2"|| $rows['seatNo'] == "I2")
                            {
                                if($rows['status'] == "Available")
                                {
                                ?>
                                <input type = "submit"  style = "border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']?>">
                            <?php
                                }
                                else
                                {?>
                                <input type = "submit"  style = "background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>"disabled>
                                <?php
                                }
                            }
                             else if($rows['seatNo'] == "B3" || $rows['seatNo'] == "C3" || $rows['seatNo'] == "D3" || $rows['seatNo'] == "E3" || $rows['seatNo'] == "F3"|| $rows['seatNo'] == "G3"|| $rows['seatNo'] == "H3"|| $rows['seatNo'] == "I3")
                            {
                                if($rows['status'] == "Available")
                                {
                                ?>
                                <input type = "submit"  style = "float:right; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['seatNo']?>"><br>
                            <?php
                                }
                                else
                                {?>
                                <input type = "submit"  style = "float: right; background: transparent; border: 1px solid black; height: 50px; width: 20%; margin: 2% 1%;" value = "<?php echo $rows['status']?>" disabled><br>
                                <?php
                                }
                            }?>
                            
                        
                    <?php
                        }
                    ?>
                    </div>
                </div>
                <div id = "stepsForm" class = "col-md-2" style = "font-size: 12px;margin-right: 1%; margin-top: 3%; margin-bottom: 5%;">
                    <h3 style = "text-align: center">Trip Information</h3><br>
                    <?php
                        $query = "SELECT * FROM bus_trips WHERE busNo = '$busNo'";
                        $result = $result = mysqli_query($conn,$query);
                        while($rows = mysqli_fetch_assoc($result))
                        {
                    ?>
                    Bus no: <input type = "text" value = "<?php echo $rows['busNo']?>" style = "text-align: center;"readOnly><br>
                    Operator: <input type = "text" value = "<?php echo $rows['operator']?>" style = "text-align: center;" readOnly>
                    Driver Name: <input type = "text" value = "<?php echo $rows['driverName']?>" style = "text-align: center; text-transform: capitalize;" readOnly>
                    Departure Date: <input type = "text" value = "<?php echo date('F d, Y',strtotime($rows['departureDate']))?>" style = "text-align: center;" readOnly>
                    Origin: <input type = "text" value = "<?php echo $rows['origin']?>" style = "text-align: center;" readOnly>
                    Departure Time: <input type = "text" value = "<?php echo $rows['departureTime']?>" style = "text-align: center;" readOnly>
                    Destination: <input type = "text" value = "<?php echo $rows['destination']?>" style = "text-align: center;" readOnly>
                    Arival Time: <input type = "text" value = "<?php echo $rows['arivalTime']?>" style = "text-align: center;" readOnly>
                    Bus Type: <input type = "text" value = "<?php echo $rows['busType']?>" style = "text-align: center;" readOnly>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>
</html>