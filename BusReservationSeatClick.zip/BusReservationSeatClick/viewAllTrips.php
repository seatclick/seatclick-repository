<?php
    session_start();

    require ("function.php");

    $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
    $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
    $query = "SELECT * FROM bus_trips";
    $result = mysqli_query($conn,$query);

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "adminIndex.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "addTrips.php">MANAGE TRIPS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">RESERVE TRIPS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">SALES</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <!-- View all bus trip form-->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-1"></div>
                <div class = "col-md-10">
                    <table border = "1%" align = "center" style = "width:80%; line-height:100%;margin-top: 5%; margin-bottom: 5%;">
                        
                        <tr>
                            <th style = "text-align: center; padding-bottom: 2%; padding-top: 2px;">Operator</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Bus Number</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Driver Name</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Departure Date</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Origin</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Departure Time</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Destination</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Arival Time</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Bus Type</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Fare</th>
                            <th style = "text-align: center; padding-bottom: 2%;">Action</th>
                        </tr>

                    <?php
                        while($rows = mysqli_fetch_assoc($result))
                        {
                    ?>
                        <tr>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['operator']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['busNo']?></td>
                            <td style = "text-align: center; padding-bottom: 2%; text-transform: capitalize;"><?php echo $rows['driverName']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['departureDate']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['origin']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['departureTime']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['destination']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['arivalTime']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['busType']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;"><?php echo $rows['fare']?></td>
                            <td style = "text-align: center; padding-bottom: 2%;">
                                <?php 
                                    if($rows['action'] == "Available")
                                    {
                                        echo "<form><input type = 'submit' value = 'Delete'><br><input type = 'submit' value = 'Edit'></form>";
                                    }
                                    else
                                    {
                                        echo "Not Available";
                                    } 
                                ?>
                            </td>
                        </tr>
                    <?php
                        }
                    ?>
                    </table>
                </div>
                <div class = "col-md-1"></div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>