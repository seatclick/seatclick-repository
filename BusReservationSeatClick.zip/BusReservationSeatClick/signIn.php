<!DOCTYPE html>
<html>

    <head>

        <title>Sign in to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Sign in Form -->
        <div class = "container-fluid">
            <div class = "row">

                <div class = "col-md-4"></div>

                <div class = "col-md-4">
                    <div id = "signForm">
                        <div id = "logoImg"><a href = "index.php"><img src = "assets/logo.png"/></a></div>
                        
                        <div id = "signInMess">Sign in to SeatClick</div>
                        
                        <div id = "signInForm">
                            <form action="signInUser.php" method = "post">
                                <div id = "usernameL">Username</div>
                                <input type="text" id = "signName" name="signName" required><br>
                                <div id = "passwordL">Password</div>
                                <input type="password" id = "signPass" name="signpass" required><br>

                                <input type="submit" name = "signInB" id = "signInB" value="Sign in">
                            </form> 
                        </div>

                    <div id = "noAccount">
                        <div id = "noAccountL">Don't have an account? <a href = "signUp.php">Create an account. </a></div>
                    </div>

                    </div>
                </div>

                <div class = "col-md-4"></div>

            </div>
        </div>


        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>