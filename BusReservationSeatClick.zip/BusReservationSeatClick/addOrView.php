<?php

        session_start();
        if(isset($_POST['addBusTrips']))
        {
            echo '<script>window.location.href = "addBusTrips.php";</script>';     
        }
        else if(isset($_POST['viewAllTrips']))
        {
            echo '<script>window.location.href = "viewAllTrips.php";</script>';     
        }
?>