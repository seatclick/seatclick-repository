<?php
    session_start();

    require ("function.php");

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "adminIndex.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "addTrips.php">MANAGE TRIPS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">RESERVE TRIPS</a></li>
                        <li><a id = "navID" href = "adminShowTrips.php">SALES</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>

            </div>
        </nav>

        <!-- Add bus trip form-->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-3"></div>
                <div class = "col-md-6" id = "addTripForm">
                    <form action = "addTripDB.php" method = "post">
                       <h3 id = "addTripL">ADD BUS TRIP</h3> 

                        <input type="text" id="busNum" name="busNum" placeholder="Bus Number" maxlength = "35" required>
                        <br>

                       <select id = "operatorForm" name = "operator">
                           <option disabled selected>Select Operator</option>
                           <option id = "operatorO" value = "Power Transit">Power Transit</option>
                       </select>

                        <br>

                        <input type="text" id="dname" name="drivername" placeholder="Driver's name" onkeyup = "lettersOnly(this)" maxlength = "35" required>
                        <br>

                        <input type="date" id = "departDate" name = "departDate" required min = "<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" />
                        <br>

                       <select id = "originForm" name = "originAdmin">
                           <option disabled selected>Select origin</option>
                           <option value = "Cubao">Cubao</option>
                       </select>

                        <select id = "departureTimeForm" name = "departureAdmin">
                           <option disabled selected>Departure time</option>
                           <option value = "8:00 AM">8:00 AM</option>
                           <option value = "9:00 AM">9:00 AM</option>
                           <option value = "10:00 AM">10:00 AM</option>
                           <option value = "11:00 AM">11:00 AM</option>
                           <option value = "12:00 PM">12:00 PM</option>
                           <option value = "1:00 PM">1:00 PM</option>
                           <option value = "2:00 PM">2:00 PM</option>
                           <option value = "3:00 PM">3:00 PM</option>
                           <option value = "4:00 PM">4:00 PM</option>
                           <option value = "5:00 PM">5:00 PM</option>
                           <option value = "6:00 PM">6:00 PM</option>
                           <option value = "7:00 PM">7:00 PM</option>
                           <option value = "8:00 PM">8:00 PM</option>
                           <option value = "9:00 PM">9:00 PM</option>
                           <option value = "10:00 PM">10:00 PM</option>
                           <option value = "11:00 PM">11:00 PM</option>
                           <option value = "12:00 AM">12:00 AM</option>
                       </select>
                        <br>
                        <select id = "destinationForm" name = "destinationAdmin">
                            <option disabled selected>Select Destination</option>
                            <option value="Cavite">Cavite</option>
                            <option value="Batangas">Batangas</option>
                            <option value="Laguna">Laguna</option>
                            <option value="Quezon">Quezon</option>
                            <option value="Baguio">Baguio</option>
                            <option value="Subic">Subic</option>
                            <option value="Pampanga">Pampanga</option>
                        </select>
                        <select id = "arivalTimeForm" name = "arivalAdmin">
                           <option disabled selected>Arival time</option>
                           <option value = "8:00 AM">8:00 AM</option>
                           <option value = "9:00 AM">9:00 AM</option>
                           <option value = "10:00 AM">10:00 AM</option>
                           <option value = "11:00 AM">11:00 AM</option>
                           <option value = "12:00 PM">12:00 PM</option>
                           <option value = "1:00 PM">1:00 PM</option>
                           <option value = "2:00 PM">2:00 PM</option>
                           <option value = "3:00 PM">3:00 PM</option>
                           <option value = "4:00 PM">4:00 PM</option>
                           <option value = "5:00 PM">5:00 PM</option>
                           <option value = "6:00 PM">6:00 PM</option>
                           <option value = "7:00 PM">7:00 PM</option>
                           <option value = "8:00 PM">8:00 PM</option>
                           <option value = "9:00 PM">9:00 PM</option>
                           <option value = "10:00 PM">10:00 PM</option>
                           <option value = "11:00 PM">11:00 PM</option>
                           <option value = "12:00 AM">12:00 AM</option>
                       </select>
                       <br>
                       <select id = "bustTypeForm" name = "busTypeAdmin">
                           <option disabled selected>Select Bus Type</option>
                           <option value = "EXECUTIVE (2X1 WITH CR)">EXECUTIVE (2X1 WITH CR)</option>
                       </select>
                        <br>

                        <input type="text" id="fareL" name="fare" placeholder = "Fare" onkeyup = "numbersOnly(this)" required>
                        <br>
                       <input type= "submit" id = "addtrip" name = "addtrip" value = "ADD TRIP">
                    </form>
                <div class = "col-md-3"></div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>