<?php

    session_start();
    if(isset($_POST['addtrip']))
    {
        $busNum = $_POST['busNum'];
        $operator = $_POST['operator'];
        $drivername = $_POST['drivername'];
        $departDate = $_POST['departDate'];
        $originAdmin = $_POST['originAdmin'];
        $departureAdmin = $_POST['departureAdmin'];
        $destinationAdmin = $_POST['destinationAdmin'];
        $arivalAdmin = $_POST['arivalAdmin'];
        $busTypeAdmin = $_POST['busTypeAdmin'];
        $fare = $_POST['fare'];


        $conn = new mysqli('localhost', 'root', ''  ) or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");

        $query = mysqli_query($conn, "SELECT * FROM bus_trips WHERE driverName = '$drivername' AND departureDate = '$departDate' AND departureTime = '$departureAdmin' AND arivalTime = '$arivalAdmin'");
        
        if(mysqli_num_rows($query) > 0)
        {
            echo '<script>alert("The trip cannot proceed.");
            window.location.href = "addBusTrips.php";</script>';
        }
        else
        {
            $drivername = mysqli_real_escape_string($conn,$_POST['drivername']);
            $departDate = mysqli_real_escape_string($conn,$_POST['departDate']);

            $sql = "CREATE TABLE `".$drivername.'_'.$departDate."` (seatNo VARCHAR(100) ,firstname VARCHAR(100), lastname VARCHAR(100),birthDate DATE, email VARCHAR(100), mobileNum VARCHAR(100), status VARCHAR(100), PRIMARY KEY (seatNo))";
            if(mysqli_query($conn, $sql))
            {
                mysqli_query($conn,"INSERT INTO `bus_trips` (`tripNo`,`busNo`,`operator`, `driverName`, `departureDate`, `origin`,`departureTime`,`destination`,`arivalTime`,`busType`,`fare`,`action`) VALUES
                ('','$busNum','$operator', '$drivername','$departDate', '$originAdmin', '$departureAdmin','$destinationAdmin','$arivalAdmin','$busTypeAdmin','$fare','Available')") or die (mysqli_error());

                for($a = 1; $a<4; $a++)
                {
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('A".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('B".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('C".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('D".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    if($a != 3)
                    {
                        mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('E".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    }
                    else
                    {
                        mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('E".$a."', NULL, NULL, NULL, NULL, NULL, 'Restroom')");
                    }
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('F".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('G".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('H".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                    mysqli_query($conn, "INSERT INTO `".$drivername.'_'.$departDate."` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES ('I".$a."', NULL, NULL, NULL, NULL, NULL, 'Available')");
                }
                
                echo '<script>alert("The trip has been added!"); 
                window.location.href = "adminIndex.php";</script>';
            }
            
            
        }

    }      
?>