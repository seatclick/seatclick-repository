<?php 


    function getUserData($id)
    {
            
        $conn = new mysqli('localhost', 'root', ''  ) or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
        $array = array();
        $query = mysqli_query($conn,"SELECT * FROM `passenger_info` WHERE `passengerID` = " .$id);
        while($row = mysqli_fetch_assoc($query))
        {
            $array['id'] = $row['passengerID']; 
            $array['firstName'] = $row['firstName']; 
            $array['middleName'] = $row['middleName']; 
            $array['lastName'] = $row['lastName']; 
            $array['emailAdd'] = $row['emailAdd']; 
            $array['gender'] = $row['gender']; 
            $array['birthDate'] = $row['birthDate']; 
            $array['mobileNum'] = $row['mobileNum']; 
            $array['userName'] = $row['userName']; 
        }
        return $array;
    }

    function getID($username)
    {
        
        $conn = new mysqli('localhost', 'root', ''  ) or die(mysqli_error());
        $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");    
        $query = mysqli_query($conn,"SELECT * FROM `passenger_info` WHERE `userName` = '" .$username."'");
        while($row = mysqli_fetch_assoc($query))
        {
            return $row['passengerID'];
        }
    }
?>