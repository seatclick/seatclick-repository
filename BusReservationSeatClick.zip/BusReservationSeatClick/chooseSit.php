<?php
    session_start();

    require ("function.php");

    if(!isset($_SESSION['username']))
    {
        header("location: signIn.php");
    } 
?>
<!DOCTYPE html>
<html>

    <head>

        <title>Welcome to SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">
        <script src="script/functions.js"></script>
        <script src = "script/functions.js" type = "application/javascript"></script>

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
                    <a href = "welcome.php"><img src = "assets/logo.png"/></a>
                </div>
 
                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "profile.php" style = "text-transform: Uppercase;">
                        <?php
                        if(isset($_SESSION['username']))
                        {
                            $userData = getUserData(getID($_SESSION['username']));
                        ?>
                        <?php 
                            echo $userData['firstName']." ".$userData['lastName'];

                        ?>
                        <?php
                            }
                        ?>
                        <li><a id = "navID" href = "trips.php">SHOW TRIP HISTORY</a></li>
                        <li><a id = "navID" href = "logout.php">LOG OUT</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Steps -->
        <div class = "container-fluid">
            <div class = "row">
                <div id = "stepsForm" class = "col-md-2" style = "margin-left: 2%; margin-top: 3%; margin-bottom: 5%;">
                    Step 1: <input id = "reserveSteps" type = "submit" value = "Plan Your Trip" style = "background: #3385ff;" disabled><br>
                    Step 2: <input id = "reserveSteps" type = "submit" value = "Choose Seats" style = "background: #3385ff;" disabled><br>
                    Step 3: <input id = "reserveSteps" type = "submit" value = "Payment">
                </div>
                <div class = "col-md-9"></div>
                <div class = "col-md-1"></div>
            </div>
        </div>

        <!--Footer-->
        <footer class = "container-fluid">
            <div class ="row">
                <div id = "footL">
                    <p id = "copyR" >© 2018 by SeatClick. Proudly created with Heart
                    <br>
                    SeatClick.com / 777-7777</p>
                </div>
            </div>
        </footer>

        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>
</html>