<?php

    require ("function.php");

    if(isset($_POST['showTripB']))
    {
        $origin = $_POST['originF'];
        $destination = $_POST['destinationF'];
        $departureDate = $_POST['departDate'];

        if($departureDate == null)
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips WHERE destination = '$destination' ORDER BY departureDate ASC";
            $result = mysqli_query($conn,$query);
        }
        else
        {
            $conn = new mysqli('localhost', 'root', '') or die(mysqli_error());
            $db = mysqli_select_db($conn, 'seatclickdb') or  die("database error");
            $query = "SELECT * FROM bus_trips WHERE destination = '$destination' AND departureDate = '$departureDate'";
            $result = mysqli_query($conn,$query);
        }
        
    }
?>
<!DOCTYPE html>
<html>

    <head>

        <title>SeatClick</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel = "shortcut icon" href = "assets/icon.ico">
        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/styles.css" rel="stylesheet">

    </head>

    <body>

        <!-- Navigation Bar -->
        <nav class = "my-nav navbar navbar-default navbar-static-top">
            <div class = "container">
                <div class = "navbar-header">
                    <button id = "toggleButton" type = "button" class = "navbar-toggle collapsed" data-toggle = "collapse" data-target = "#menuItems" aria-expanded = "false">
                        <span class = "sr-only">Toggle Navigation</span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                        <span class = "icon-bar"></span>
                    </button>
					<a href = "index.php"><img src = "assets/logo.png"/></a>
                </div>

                <div class = "collapse  navbar-collapse navbar-right" id = "menuItems">
                    <ul class = "nav navbar-nav">
                        <li><a id = "navID" href = "faqs.html">FAQs</a></li>
                        <li><a id = "navID" href = "signIn.php">SIGN IN</a></li>
                        <li><a id = "navID" href = "signUp.php">SIGN UP</a></li>
                        <li><a id = "navID" href = "contactUs.php">CONTACT US</a></li>
                    </ul>
                </div>

            </div>
        </nav>

         <!-- Pick Origin,Destination and Date-->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-2"></div>

                <div class = "col-md-8">

                    <div id = "showTripFormUser">
                        <form action = "showTripIndex.php" method = "post">
                            <select name = "originF" id = "originF" required>
                                <option id = "originO" value = "Cubao" selected>Cubao</option>
                            </select>

                            <select name = "destinationF" id = "destinationF" required>
                                <option id = "destinationO" value="Batangas">Batangas</option>
                                <option id = "destinationO" value="Baguio">Baguio</option>
                                <option id = "destinationO" value="Cavite">Cavite</option>
                                <option id = "destinationO" value="Laguna">Laguna</option>
                                <option id = "destinationO" value="Quezon">Quezon</option>
                                <option id = "destinationO" value="Subic">Subic</option>
                                <option id = "destinationO" value="Pampanga">Pampanga</option>
                            </select>

                            <input type="date" id = "depDate" name = "departDate" min = "<?php echo date('Y-m-d'); ?>"  />
                            <input type="submit" id = "showTripB" name = "showTripB" value = "Show Trips">
                        </form>
                    </div>
                </div>

                <div class = "col-md-2"></div>
            </div>
        </div>

        <!-- Steps -->
        <div class = "container-fluid">
            <div class = "row">
                <div class = "col-md-1"></div>
                
                <div id = "tableForm" class = "col-md-10" style = "margin-bottom: 5%;">
                    <div class = "table-responsive">
                        <table class="table table-striped">
                            <thead id = "tableHead">
                                    <div id = "theadL" style = "text-transform: uppercase; margin-bottom: 2%; margin-top: 2%;">TRIPS YOU SEARCHED</div>
                                
                                <tr  id = "columnName" class = "info">
                                    <th id = "thName">Operator</th>
                                    <th id = "thName">Driver Name</th>
                                    <th id = "thName">Bus Number</th>
                                    <th id = "thName">Departure Date</th>
                                    <th id = "thName">Origin</th> 
                                    <th id = "thName">Departure</th>
                                    <th id = "thName">Destination</th>
                                    <th id = "thName">Estimated Arrival</th>
                                    <th id = "thName">Bus Type</th>
                                    <th id = "thName">Fare</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    while($rows = mysqli_fetch_assoc($result))
                                    {
                                ?>
                                    <tr id = "rowsName">
                                        <td id = "tdName"><?php echo $rows['operator']?></td>
                                        <td id = "tdName"><?php echo $rows['busNo']?></td>
                                        <td id = "tdName" style = "text-transform: capitalize;"><?php echo $rows['driverName']?></td>
                                        <td id = "tdName"><?php echo date('F d, Y',strtotime($rows['departureDate']))?></td>
                                        <td id = "tdName"><?php echo $rows['origin']?></td>
                                        <td id = "tdName"><?php echo $rows['departureTime']?></td>
                                        <td id = "tdName"><?php echo $rows['destination']?></td>
                                        <td id = "tdName"><?php echo $rows['arivalTime']?></td>
                                        <td id = "tdName"><?php echo $rows['busType']?></td>
                                        <td id = "tdName"><?php echo $rows['fare']?></td>
                                    </tr>
                                <?php
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class = "col-md-1"></div>
            </div>
        </div>


        <script src="script/jquery.js"></script>
        <script src="script/bootstrap.js"></script>

    </body>

</html>