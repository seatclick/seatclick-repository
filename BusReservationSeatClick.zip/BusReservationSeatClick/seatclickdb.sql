-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2018 at 03:49 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `seatclickdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `transNo` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `driverName` varchar(100) DEFAULT NULL,
  `departureDate` date DEFAULT NULL,
  `origin` varchar(25) DEFAULT NULL,
  `departureTime` varchar(25) DEFAULT NULL,
  `destination` varchar(25) DEFAULT NULL,
  `arivalTime` varchar(25) DEFAULT NULL,
  `fare` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `antonio dela luna_2018-03-30`
--

CREATE TABLE `antonio dela luna_2018-03-30` (
  `seatNo` varchar(100) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobileNum` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `antonio dela luna_2018-03-30`
--

INSERT INTO `antonio dela luna_2018-03-30` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES
('A1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('A2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('A3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E3', NULL, NULL, NULL, NULL, NULL, 'Restroom'),
('F1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('F2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('F3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I3', NULL, NULL, NULL, NULL, NULL, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `bus_info`
--

CREATE TABLE `bus_info` (
  `busNo` varchar(255) NOT NULL,
  `plateNo` varchar(255) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `driverName` varchar(255) NOT NULL,
  `busType` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `bus_trips`
--

CREATE TABLE `bus_trips` (
  `tripNo` int(11) NOT NULL,
  `busNo` varchar(255) NOT NULL,
  `operator` varchar(255) NOT NULL,
  `driverName` varchar(255) NOT NULL,
  `departureDate` date NOT NULL,
  `origin` varchar(255) NOT NULL,
  `departureTime` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `arivalTime` varchar(255) NOT NULL,
  `busType` varchar(255) NOT NULL,
  `fare` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bus_trips`
--

INSERT INTO `bus_trips` (`tripNo`, `busNo`, `operator`, `driverName`, `departureDate`, `origin`, `departureTime`, `destination`, `arivalTime`, `busType`, `fare`, `action`) VALUES
(14, 'LUV-231', 'Power Transit', 'Winnie Morde', '2018-03-30', 'Cubao', '8:00 AM', 'Baguio', '2:00 PM', 'EXECUTIVE (2X1 WITH CR)', '750', 'Available'),
(15, 'SJE-198', 'Power Transit', 'Antonio Dela Luna', '2018-03-30', 'Cubao', '8:00 AM', 'Batangas', '11:00 AM', 'EXECUTIVE (2X1 WITH CR)', '550', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `destination`
--

CREATE TABLE `destination` (
  `arivalPlace` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `destination`
--

INSERT INTO `destination` (`arivalPlace`) VALUES
('Batangas'),
('Baguio'),
('Cavite'),
('Laguna'),
('Quezon'),
('Subic'),
('Pampanga');

-- --------------------------------------------------------

--
-- Table structure for table `djsdeguzman`
--

CREATE TABLE `djsdeguzman` (
  `transNo` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `driverName` varchar(100) DEFAULT NULL,
  `departureDate` date DEFAULT NULL,
  `origin` varchar(25) DEFAULT NULL,
  `departureTime` varchar(25) DEFAULT NULL,
  `destination` varchar(25) DEFAULT NULL,
  `arivalTime` varchar(25) DEFAULT NULL,
  `fare` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `origin`
--

CREATE TABLE `origin` (
  `depPlace` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `origin`
--

INSERT INTO `origin` (`depPlace`) VALUES
('Cubao');

-- --------------------------------------------------------

--
-- Table structure for table `passenger_info`
--

CREATE TABLE `passenger_info` (
  `passengerID` int(11) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `middleName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `emailAdd` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `birthDate` date NOT NULL,
  `mobileNum` varchar(255) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `passenger_info`
--

INSERT INTO `passenger_info` (`passengerID`, `firstName`, `middleName`, `lastName`, `emailAdd`, `gender`, `birthDate`, `mobileNum`, `userName`, `password`) VALUES
(1, 'karl henry', 'agno', 'balbero', 'khabalbero@gmail.com', 'male', '1998-11-26', '09154122549', 'admin', 'adminadmin'),
(2, 'diana jean', 'san diego', 'de guzman', 'djsdeguzman@gmail.com', 'female', '1999-05-23', '09776980747', 'djsdeguzman', 'dianajean'),
(3, 'ralph vincent', 'perez', 'malabanan', 'rvpmalabanan@gmail.com', 'male', '1999-07-19', '09547854122', 'rvpmalabanan', 'ralphmalabanan'),
(4, 'Shanaya Alyza', 'Banua', 'Bibit', 'sabbibit@gmail.com', 'female', '1999-03-19', '09254787812', 'sabbibit', 'shanayabibit');

-- --------------------------------------------------------

--
-- Table structure for table `rvpmalabanan`
--

CREATE TABLE `rvpmalabanan` (
  `transNo` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `driverName` varchar(100) DEFAULT NULL,
  `departureDate` date DEFAULT NULL,
  `origin` varchar(25) DEFAULT NULL,
  `departureTime` varchar(25) DEFAULT NULL,
  `destination` varchar(25) DEFAULT NULL,
  `arivalTime` varchar(25) DEFAULT NULL,
  `fare` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sabbibit`
--

CREATE TABLE `sabbibit` (
  `transNo` int(11) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `operator` varchar(100) DEFAULT NULL,
  `driverName` varchar(100) DEFAULT NULL,
  `departureDate` date DEFAULT NULL,
  `origin` varchar(25) DEFAULT NULL,
  `departureTime` varchar(25) DEFAULT NULL,
  `destination` varchar(25) DEFAULT NULL,
  `arivalTime` varchar(25) DEFAULT NULL,
  `fare` varchar(20) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

CREATE TABLE `user_accounts` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`username`, `password`) VALUES
('admin', 'adminadmin'),
('djsdeguzman', 'dianajean'),
('rvpmalabanan', 'ralphmalabanan'),
('sabbibit', 'shanayabibit');

-- --------------------------------------------------------

--
-- Table structure for table `winnie morde_2018-03-30`
--

CREATE TABLE `winnie morde_2018-03-30` (
  `seatNo` varchar(100) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `birthDate` date DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobileNum` varchar(100) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `winnie morde_2018-03-30`
--

INSERT INTO `winnie morde_2018-03-30` (`seatNo`, `firstname`, `lastname`, `birthDate`, `email`, `mobileNum`, `status`) VALUES
('A1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('A2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('A3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('B3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('C3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('D3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('E3', NULL, NULL, NULL, NULL, NULL, 'Restroom'),
('F1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('F2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('F3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('G3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('H3', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I1', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I2', NULL, NULL, NULL, NULL, NULL, 'Available'),
('I3', NULL, NULL, NULL, NULL, NULL, 'Available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`transNo`);

--
-- Indexes for table `antonio dela luna_2018-03-30`
--
ALTER TABLE `antonio dela luna_2018-03-30`
  ADD PRIMARY KEY (`seatNo`);

--
-- Indexes for table `bus_info`
--
ALTER TABLE `bus_info`
  ADD PRIMARY KEY (`busNo`);

--
-- Indexes for table `bus_trips`
--
ALTER TABLE `bus_trips`
  ADD PRIMARY KEY (`tripNo`);

--
-- Indexes for table `djsdeguzman`
--
ALTER TABLE `djsdeguzman`
  ADD PRIMARY KEY (`transNo`);

--
-- Indexes for table `passenger_info`
--
ALTER TABLE `passenger_info`
  ADD PRIMARY KEY (`passengerID`);

--
-- Indexes for table `rvpmalabanan`
--
ALTER TABLE `rvpmalabanan`
  ADD PRIMARY KEY (`transNo`);

--
-- Indexes for table `sabbibit`
--
ALTER TABLE `sabbibit`
  ADD PRIMARY KEY (`transNo`);

--
-- Indexes for table `user_accounts`
--
ALTER TABLE `user_accounts`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `winnie morde_2018-03-30`
--
ALTER TABLE `winnie morde_2018-03-30`
  ADD PRIMARY KEY (`seatNo`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `transNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bus_trips`
--
ALTER TABLE `bus_trips`
  MODIFY `tripNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `djsdeguzman`
--
ALTER TABLE `djsdeguzman`
  MODIFY `transNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `passenger_info`
--
ALTER TABLE `passenger_info`
  MODIFY `passengerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rvpmalabanan`
--
ALTER TABLE `rvpmalabanan`
  MODIFY `transNo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sabbibit`
--
ALTER TABLE `sabbibit`
  MODIFY `transNo` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
